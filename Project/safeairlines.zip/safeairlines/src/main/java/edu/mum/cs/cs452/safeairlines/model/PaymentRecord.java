package edu.mum.cs.cs452.safeairlines.model;

import javax.persistence.Entity;

public class PaymentRecord {
}
