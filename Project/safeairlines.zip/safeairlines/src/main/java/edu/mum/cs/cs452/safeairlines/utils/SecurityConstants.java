package edu.mum.cs.cs452.safeairlines.utils;

public class SecurityConstants {
    final public static long ROLE_ADMIN = 1;
    final public static long ROLE_BUYER = 2;
}
