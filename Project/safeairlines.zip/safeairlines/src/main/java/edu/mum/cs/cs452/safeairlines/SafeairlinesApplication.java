package edu.mum.cs.cs452.safeairlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeairlinesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SafeairlinesApplication.class, args);
    }

}
