package edu.mum.cs.cs452.safeairlines.service;

import edu.mum.cs.cs452.safeairlines.model.Role;

public interface RoleService {

    Role getRoleById(Long id);
}
